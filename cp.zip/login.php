<?php  
include 'dbconnect.php';
      $myusername =$_POST['username'];;
      $mypassword =$_POST['password'];

      if($myusername == 'admin' && $mypassword == 'admin@123')
      {
          echo "Login successfully";
          header('location:add_list.php');
      }
      else
      {

        $login = "SELECT * FROM `users` WHERE `username` = '$myusername' AND `password`= '$mypassword'";
        $result = $conn->query($login);
        $res =mysqli_fetch_object($result);
        if($result->num_rows > 0)
        {
          session_start();
          $_SESSION['username']=$res->username;
          // $_SESSION['username'];
          $_SESSION['expdate'] = $res->expdate;
          $_SESSION['status'] = $res->status;
          $_SEESION['password']=$res->password;
          header('Location:coupon.php');
        }
        else
        { 
          header("location: index.php");
        }
      }
      



?>
        
