<?php
include 'dbconnect.php';	
	$cp_code = $_POST['cpcode'];
	$file_type=$_FILES['txt_file']['type'];
	$allow_type=array('text/plain');
	if(in_array($file_type,$allow_type))
	{
		move_uploaded_file($_FILES['txt_file']['tmp_name'],"files/".$_FILES['txt_file']['name']);
		$file=fopen("files/".$_FILES['txt_file']['name'],"r");
		while (!feof($file)) {
		$line = fgets($file);
		$array = explode(",",$line);
		list($phone) = $array;
		$sql = "INSERT INTO list (cp_code,phone) VALUES('$cp_code',
		$phone)";
		$ex= $conn->query($sql);
		}
		//$ex= $conn->query($sql);
		fclose($file);
		// if($conn->query($sql))
		// {
		// 	echo "Yes";
		// 	echo "txt file upload";
		// }
		// else
		// {
		// 	echo "No";
		// }
		if($ex)
		{?>
			<!-- <div class="page-center">
        <div class="page-center-in">
            <div class="container-fluid">
                <form class="sign-box" action="index.php" method="POST">
                    <div class="no-photo" style="text-align: center;"><img src="image/logo.png"></div>
                    <header class="sign-title">Validate Updates</header>
                    <div class="alert alert-aquamarine alert-border-left alert-close alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                            <strong>Hurrya!</strong>Your file upload has been done!
                        </div><button type="submit" class="btn btn-rounded btn-success sign-up">Thank You!</button>
                    
                    
                </form>
            </div>
        </div>
    </div>  -->
		<?php  }
		else
		{?>
		<!-- <div class="page-center">
         <div class="page-center-in">
             <div class="container-fluid">
                 <form class="sign-box" action="add_list.php" method="POST">
                     <div class="no-photo" style="text-align: center;"><img src="image/logo.png"></div>
                     <header class="sign-title">Validate Updates</header>
                    

                     <div class="alert alert-danger alert-border-left alert-close alert-dismissible fade in" role="alert">
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true">×</span>
                             </button>
                             <strong>Sorry!</strong> Your file not be choose..
                         </div>
                   

                    
                    
                     <button type="submit" class="btn btn-rounded btn-success sign-up">Go Back and Check</button>
                    
                    
                 </form>
             </div>
         </div>
     </div> -->
		<?php  }
	}
	
		


?>
<!DOCTYPE html>
<html>

<!-- sign-up.html  16:14 GMT -->
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Bharat Jewels</title>

	<link href="img/favicon.144x144.html" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.html" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.html" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.html" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.html" rel="icon" type="image/png">
	<link href="img/favicon-2.html" rel="shortcut icon">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
    <link rel="stylesheet" href="css/lib/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>


<script src="js/app.js"></script>
</body>

<!-- sign-up.html  16:14 GMT -->
</html>